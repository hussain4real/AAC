/* ============================================================
   MAAC — App root, routing, theme
   ============================================================ */
function PlaceholderScreen({ name }) {
  return (
    <div className="route-anim">
      <PageHeader title={name} sub="This screen is being assembled." />
      <Card><EmptyState icon="flask" title="Coming together" desc={`The ${name} screen will appear here.`} /></Card>
    </div>
  );
}

function NoAccess({ kind = "item" }) {
  const { go, scope } = useNav();
  return (
    <div className="route-anim">
      <Card style={{ borderColor:"var(--amber-500)" }}>
        <EmptyState icon="lock" title="Not in your current view"
          desc={`This ${kind} isn't part of the ${scope.role.view} (${scope.role.name}). Switch views from the account menu in the top-left, or return to your dashboard.`}
          action={<Btn variant="primary" icon="dashboard" onClick={() => go("dashboard")}>Back to Dashboard</Btn>} />
      </Card>
    </div>
  );
}
window.NoAccess = NoAccess;

class ErrorBoundary extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(err) { return { err }; }
  componentDidUpdate(prev) { if (prev.routeKey !== this.props.routeKey && this.state.err) this.setState({ err: null }); }
  render() {
    if (this.state.err) {
      return (
        <div className="route-anim">
          <Card style={{ borderColor: "var(--red-500)" }}>
            <EmptyState icon="alert" title="This screen hit an error"
              desc={String(this.state.err && this.state.err.message || this.state.err)}
              action={<Btn variant="primary" icon="dashboard" onClick={this.props.onHome}>Back to Dashboard</Btn>} />
          </Card>
        </div>
      );
    }
    return this.props.children;
  }
}

function renderScreen(nav) {
  const map = {
    dashboard: () => <Dashboard />,
    applications: () => window.Applications ? <window.Applications /> : <PlaceholderScreen name="Applications" />,
    application: () => window.ApplicationDetail ? <window.ApplicationDetail id={nav.params.id} /> : <PlaceholderScreen name="Application" />,
    projects: () => window.Projects ? <window.Projects /> : <PlaceholderScreen name="Projects" />,
    agents: () => window.Agents ? <window.Agents /> : <PlaceholderScreen name="Agents" />,
    agent: () => window.AgentDetail ? <window.AgentDetail id={nav.params.id} /> : <PlaceholderScreen name="Agent" />,
    createAgent: () => window.CreateAgent ? <window.CreateAgent /> : <PlaceholderScreen name="Create Agent" />,
    tools: () => window.Tools ? <window.Tools /> : <PlaceholderScreen name="Tools" />,
    tool: () => window.ToolDetail ? <window.ToolDetail id={nav.params.id} /> : <PlaceholderScreen name="Tool" />,
    sdk: () => window.SDKCenter ? <window.SDKCenter /> : <PlaceholderScreen name="SDK Implementation Center" />,
    playground: () => window.Playground ? <window.Playground /> : <PlaceholderScreen name="Agent Playground" />,
    runs: () => window.Runs ? <window.Runs /> : <PlaceholderScreen name="Runs & Audit Logs" />,
    run: () => window.RunTrace ? <window.RunTrace id={nav.params.id} /> : <PlaceholderScreen name="Run Trace" />,
    llm: () => window.LLMProviders ? <window.LLMProviders /> : <PlaceholderScreen name="LLM Providers" />,
    governance: () => window.Governance ? <window.Governance /> : <PlaceholderScreen name="Governance" />,
    settings: () => window.Settings ? <window.Settings /> : <PlaceholderScreen name="Settings" />,
  };
  return (map[nav.name] || (() => <PlaceholderScreen name={nav.name} />))();
}

function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem("maac-theme") || "light");
  const [env, setEnv] = useState("Production");
  const [personaId, setPersonaId] = useState(() => localStorage.getItem("maac-persona") || "admin");
  const persona = PERSONAS.find(p => p.id === personaId) || PERSONAS[0];
  const scope = React.useMemo(() => computeScope(persona), [personaId]);
  const [history, setHistory] = useState([{ name:"dashboard", params:{} }]);
  const nav = history[history.length - 1];
  const scrollRef = useRef(null);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("maac-theme", theme);
  }, [theme]);

  const go = useCallback((name, params = {}) => {
    setHistory(h => [...h, { name, params }]);
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, []);
  const back = useCallback(() => setHistory(h => h.length > 1 ? h.slice(0, -1) : h), []);
  const replace = useCallback((name, params = {}) => setHistory(h => [...h.slice(0, -1), { name, params }]), []);

  const setPersona = useCallback((p) => {
    setPersonaId(p.id);
    localStorage.setItem("maac-persona", p.id);
    setHistory([{ name:"dashboard", params:{} }]); // reset to a screen everyone can see
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, []);

  // if current screen isn't allowed for this role, bounce to dashboard
  useEffect(() => {
    const screen = SCREEN_OF[nav.name] || nav.name;
    if (!navAllowed(persona.id, screen)) replace("dashboard");
  }, [nav.name, persona.id]);

  const ctx = { nav, go, back, replace, env, setEnv, theme, setTheme, canBack: history.length > 1, persona, setPersona, scope };

  return (
    <NavContext.Provider value={ctx}>
      <div style={{ display:"flex", height:"100vh", overflow:"hidden" }}>
        <Sidebar />
        <div style={{ flex:1, display:"flex", flexDirection:"column", minWidth:0 }}>
          <Topbar theme={theme} setTheme={setTheme} env={env} setEnv={setEnv} />
          <main ref={scrollRef} className="maac-scroll" style={{ flex:1, overflowY:"auto", background:"var(--bg)" }}>
            <div style={{ maxWidth:1320, margin:"0 auto", padding:"22px 26px 60px" }}>
              <ErrorBoundary routeKey={nav.name + JSON.stringify(nav.params)} onHome={() => go("dashboard")}>
                {renderScreen(nav)}
              </ErrorBoundary>
            </div>
          </main>
        </div>
      </div>
      {window.TweaksMount && <window.TweaksMount theme={theme} setTheme={setTheme} />}
    </NavContext.Provider>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
