/* ============================================================
   MAAC — Tool Registry + Tool Detail
   ============================================================ */
function Tools() {
  const { go, scope } = useNav();
  const [q, setQ] = useState("");
  const [scopeF, setScopeF] = useState("All");
  const [mode, setMode] = useState("All");
  const [showCreate, setShowCreate] = useState(false);

  const list = scope.tools.filter(t =>
    (scopeF === "All" || t.scope === scopeF) &&
    (mode === "All" || t.execMode === mode) &&
    (t.name.toLowerCase().includes(q.toLowerCase()) || t.desc.toLowerCase().includes(q.toLowerCase())));

  const counts = {
    total:scope.tools.length,
    client:scope.tools.filter(t => t.execMode === "client").length,
    needsImpl:scope.tools.filter(t => ["required", "outdated", "incompatible"].includes(t.impl)).length,
    approval:scope.tools.filter(t => t.approval).length,
  };

  return (
    <div className="route-anim">
      <PageHeader title="Tool Registry" sub="Central catalog of tool contracts. MAAC owns the definition & governance; execution lives where the contract specifies."
        actions={<><Btn variant="default" icon="sdk" onClick={() => go("sdk")}>SDK Center</Btn><Btn variant="primary" icon="plus" onClick={() => setShowCreate(true)}>Create Tool</Btn></>} />

      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12, marginBottom:16 }}>
        <StatCard label="Total tools" value={counts.total} icon="tools" tone="purple" />
        <StatCard label="Client-side" value={counts.client} icon="link" tone="orange" sub="Implemented by applications" />
        <StatCard label="Need implementation" value={counts.needsImpl} icon="alert" tone="red" />
        <StatCard label="Require approval" value={counts.approval} icon="shield" tone="amber" />
      </div>

      <div style={{ display:"flex", gap:9, marginBottom:14, flexWrap:"wrap", alignItems:"center" }}>
        <div style={{ position:"relative", width:240 }}>
          <Icon name="search" size={15} style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", color:"var(--text-3)" }} />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search tools…" className="maac-input" style={{ ...inputStyle, paddingLeft:34 }} />
        </div>
        <Select value={scopeF} onChange={setScopeF} options={[{ value:"All", label:"All scopes" }, "Global", "Project", "Agent"]} style={{ width:150 }} />
        <Select value={mode} onChange={setMode} options={[{ value:"All", label:"All execution modes" }, ...Object.keys(MAAC.execModeLabel).map(k => ({ value:k, label:MAAC.execModeLabel[k] }))]} style={{ width:200 }} />
        <div style={{ flex:1 }} />
        <span style={{ fontSize:12, color:"var(--text-3)" }}>{list.length} tools</span>
      </div>

      <Table columns={[{ label:"Tool" }, { label:"Scope" }, { label:"Execution mode" }, { label:"Sensitivity" }, { label:"Approval", align:"center" }, { label:"Used by", align:"center" }, { label:"Status" }, { label:"" }]}>
        {list.map(t => (
          <Tr key={t.id} onClick={() => go("tool", { id:t.id })}>
            <Td strong><div><span className="mono" style={{ fontSize:13, fontWeight:600, color:"var(--text)" }}>{t.name}</span><div style={{ fontSize:11.5, color:"var(--text-3)", fontWeight:400, maxWidth:320, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{t.desc}</div></div></Td>
            <Td>{scopeBadge(t.scope)}</Td>
            <Td><ExecChip mode={t.execMode} /></Td>
            <Td><SensBadge level={t.sensitivity} /></Td>
            <Td align="center">{t.approval ? <Icon name="check" size={15} style={{ color:"var(--teal-600)" }} /> : <span style={{ color:"var(--text-3)" }}>—</span>}</Td>
            <Td align="center" mono>{t.usedBy.length}</Td>
            <Td>{t.execMode === "client" ? <ImplBadge status={t.impl} /> : <Badge tone="teal" dot>Ready</Badge>}</Td>
            <Td align="right"><Icon name="chevright" size={15} style={{ color:"var(--text-3)" }} /></Td>
          </Tr>
        ))}
      </Table>

      <Modal open={showCreate} onClose={() => setShowCreate(false)} icon="tools" title="Create Tool Contract" sub="Define a tool. Execution mode determines where it runs." width={600}
        footer={<><Btn variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Btn><Btn variant="primary" icon="check" onClick={() => setShowCreate(false)}>Create Contract</Btn></>}>
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
          <Field label="Tool name" required hint="camelCase identifier the agent will call"><Input placeholder="getBusinessData" style={{ fontFamily:"var(--mono)" }} /></Field>
          <Field label="Description" required><Textarea rows={2} placeholder="What does this tool retrieve or do?" /></Field>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
            <Field label="Scope" required><Select value="Project" onChange={() => {}} options={["Global", "Project", "Agent"]} /></Field>
            <Field label="Execution mode" required><Select value="client" onChange={() => {}} options={Object.keys(MAAC.execModeLabel).map(k => ({ value:k, label:MAAC.execModeLabel[k] }))} /></Field>
          </div>
          <div style={{ display:"flex", gap:10, padding:"11px 13px", background:"var(--orange-100)", borderRadius:"var(--r-md)", border:"1px solid var(--orange-400)" }}>
            <Icon name="link" size={17} style={{ color:"var(--orange-600)", flexShrink:0 }} />
            <div style={{ fontSize:12, color:"var(--text-2)", lineHeight:1.5 }}>Client-side tools are defined here but <b>implemented in the owning application</b> via the SDK. MAAC will generate stubs to copy.</div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

/* ============================ TOOL DETAIL ============================ */
function ToolDetail({ id }) {
  const { go, scope } = useNav();
  const tool = MAAC.toolById(id);
  const [tab, setTab] = useState("overview");
  if (!tool) return <PlaceholderScreen name="Tool" />;
  if (!scope.has.tool(id)) return <NoAccess kind="tool" />;
  const isClient = tool.execMode === "client";
  const usedByAgents = tool.usedBy.map(a => MAAC.agentById(a)).filter(Boolean);

  return (
    <div className="route-anim">
      <PageHeader
        breadcrumb={[{ label:"Tools", onClick:() => go("tools") }, { label:tool.name }]}
        title={<span className="mono" style={{ fontSize:21 }}>{tool.name}</span>}
        badge={<>{scopeBadge(tool.scope)}<ExecChip mode={tool.execMode} /></>}
        sub={tool.desc}
        actions={<><Btn variant="default" icon="edit">Edit</Btn>{isClient && <Btn variant="default" icon="code">Generate SDK Stub</Btn>}<Btn variant="primary" icon="link">Assign to Agent</Btn></>}
      />

      {isClient && (
        <div style={{ display:"flex", gap:12, padding:"14px 16px", background:"linear-gradient(100deg, var(--orange-100), transparent)", borderRadius:"var(--r-lg)", border:"1px solid var(--orange-400)", marginBottom:16 }}>
          <span style={{ width:40, height:40, borderRadius:10, background:"var(--orange-600)", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}><Icon name="link" size={21} /></span>
          <div>
            <div style={{ fontSize:13.5, fontWeight:700, color:"var(--text)" }}>Client-side tool — implemented by the integrating application</div>
            <div style={{ fontSize:12.5, color:"var(--text-2)", lineHeight:1.5, marginTop:3 }}>This tool must be implemented inside the integrating application using the MAAC SDK. <b>MAAC defines the contract; the application owns the execution.</b> MAAC never accesses the application's database directly.</div>
          </div>
        </div>
      )}

      <div style={{ display:"grid", gridTemplateColumns:"1fr 320px", gap:14 }}>
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
            <Card pad={false}>
              <div style={{ padding:"11px 14px", borderBottom:"1px solid var(--border)", display:"flex", alignItems:"center", gap:8 }}><Icon name="download" size={14} style={{ color:"var(--primary)" }} /><span style={{ fontSize:12.5, fontWeight:700 }}>Input schema</span></div>
              <CodeBlock code={schemaJson(tool.input)} lang="json" style={{ border:"none", borderRadius:0 }} />
            </Card>
            <Card pad={false}>
              <div style={{ padding:"11px 14px", borderBottom:"1px solid var(--border)", display:"flex", alignItems:"center", gap:8 }}><Icon name="external" size={14} style={{ color:"var(--teal-600)" }} /><span style={{ fontSize:12.5, fontWeight:700 }}>Output schema</span></div>
              <CodeBlock code={schemaJson(tool.output)} lang="json" style={{ border:"none", borderRadius:0 }} />
            </Card>
          </div>

          {isClient && <SDKStubs tool={tool} />}

          <Card pad={false}>
            <div style={{ padding:"14px 16px 12px" }}><SectionHeader title={`Implementation status by application`} icon="apps" style={{ marginBottom:0 }} /></div>
            <Table columns={[{ label:"Application" }, { label:"Environment" }, { label:"Status" }, { label:"Last validated", align:"right" }]}>
              {(isClient ? [MAAC.appById(tool.appId)].filter(Boolean) : MAAC.apps.slice(0, 2)).map(app => (
                <Tr key={app.id} onClick={() => go("application", { id:app.id })}>
                  <Td strong><div style={{ display:"flex", alignItems:"center", gap:9 }}><AppMark code={app.id} size={26} />{app.name}</div></Td>
                  <Td><EnvBadge env={app.env} /></Td>
                  <Td>{isClient ? <ImplBadge status={tool.impl} /> : <Badge tone="teal" dot>Hosted by MAAC</Badge>}</Td>
                  <Td align="right" style={{ color:"var(--text-3)" }}>{tool.impl === "implemented" ? "2 hours ago" : tool.impl === "outdated" ? "8 days ago" : "Never"}</Td>
                </Tr>
              ))}
            </Table>
          </Card>

          <Card>
            <SectionHeader title="Audit history" icon="runs" />
            <Timeline items={[
              { icon:"plus", color:"var(--primary)", title:"Tool contract created", by:tool.owner === "Platform" ? "platform.admin" : "developer", time:"3 weeks ago" },
              { icon:"edit", color:"var(--blue-500)", title:`Input schema updated to ${tool.scope === "Agent" ? "v2" : "v1"}`, by:"r.saleh", time:"8 days ago" },
              ...(tool.impl === "implemented" ? [{ icon:"check2", color:"var(--teal-600)", title:"Implementation validated successfully", by:"sdk.sync", time:"2 hours ago" }] : []),
              ...(tool.impl === "outdated" ? [{ icon:"alert", color:"var(--amber-500)", title:"Implementation flagged outdated — schema drift", by:"sdk.sync", time:"8 days ago" }] : []),
              ...(tool.approval ? [{ icon:"shield", color:"var(--purple-600)", title:"Approved for production use", by:"k.almansoori", time:"5 days ago" }] : []),
            ]} />
          </Card>
        </div>

        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <Card>
            <SectionHeader title="Contract" icon="info" />
            <KV cols={1} items={[
              { k:"Execution mode", v:<ExecChip mode={tool.execMode} /> },
              { k:"Scope", v:scopeBadge(tool.scope) },
              { k:"Data sensitivity", v:<SensBadge level={tool.sensitivity} /> },
              { k:"Requires approval", v:tool.approval ? "Yes" : "No" },
              { k:"Timeout", v:tool.timeout, mono:true },
              { k:"Max payload", v:tool.maxPayload, mono:true },
              { k:"Owner", v:tool.owner === "Platform" ? "Platform team" : MAAC.appById(tool.owner)?.name || tool.owner },
            ]} />
          </Card>
          <Card>
            <SectionHeader title={`Used by ${usedByAgents.length} agents`} icon="agents" />
            <div style={{ display:"flex", flexDirection:"column", gap:7 }}>
              {usedByAgents.map(a => (
                <div key={a.id} className="maac-row" onClick={() => go("agent", { id:a.id })} style={{ display:"flex", alignItems:"center", gap:9, padding:"7px 9px", borderRadius:7, cursor:"pointer" }}>
                  <span style={{ width:26, height:26, borderRadius:7, background:"var(--primary-soft)", color:"var(--primary)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}><Icon name="agents" size={14} /></span>
                  <div style={{ flex:1, minWidth:0 }}><div style={{ fontSize:12.5, fontWeight:600, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{a.name}</div></div>
                  <AgentBadge status={a.status} />
                </div>
              ))}
            </div>
          </Card>
          <Btn variant="danger" icon="archive" full>Deprecate Tool</Btn>
        </div>
      </div>
    </div>
  );
}

function schemaJson(obj) {
  const props = Object.entries(obj).map(([k, v]) => {
    const [type, fmt] = String(v).split("·");
    const opt = type.includes("?");
    return `    "${k}": { "type": "${type.replace("?", "").trim()}"${fmt ? `, "format": "${fmt.trim()}"` : ""}${opt ? "" : ""} }`;
  }).join(",\n");
  const required = Object.entries(obj).filter(([k, v]) => !String(v).includes("?")).map(([k]) => `"${k}"`);
  return `{\n  "type": "object",\n  "properties": {\n${props}\n  },\n  "required": [${required.join(", ")}]\n}`;
}

function Timeline({ items }) {
  return (
    <div style={{ display:"flex", flexDirection:"column" }}>
      {items.map((it, i) => (
        <div key={i} style={{ display:"flex", gap:12 }}>
          <div style={{ display:"flex", flexDirection:"column", alignItems:"center" }}>
            <span style={{ width:28, height:28, borderRadius:999, background:"var(--surface-2)", border:`1.5px solid ${it.color}`, color:it.color, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}><Icon name={it.icon} size={14} /></span>
            {i < items.length - 1 && <span style={{ flex:1, width:2, background:"var(--border)", minHeight:14 }} />}
          </div>
          <div style={{ paddingBottom:i < items.length - 1 ? 16 : 0 }}>
            <div style={{ fontSize:12.5, fontWeight:600 }}>{it.title}</div>
            <div style={{ fontSize:11.5, color:"var(--text-3)", marginTop:2, display:"flex", alignItems:"center", gap:6 }}><Avatar name={it.by} size={15} />{it.by} · {it.time}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function SDKStubs({ tool }) {
  const [lang, setLang] = useState("ts");
  const fn = tool.name;
  const argList = Object.keys(tool.input);
  const stubs = {
    ts:`import { maac } from "./maac-client";

// MAAC defines the contract; your app owns the execution.
maac.registerTool("${fn}", async (args, ctx) => {
  // 1. Enforce the caller's permissions
  if (!ctx.user.hasPermission("${tool.id.replace(/^get/, "").toLowerCase()}:read")) {
    return { status: "rejected", reason: "Not permitted" };
  }

  // 2. Query YOUR application's own data
  const data = await db.query({
${argList.map(a => `    ${a}: args.${a},`).join("\n")}
  });

  // 3. Return a result matching the output schema
  return { summary: data.summary, records: data.records };
});`,
    php:`<?php
use Milaha\\MAAC\\Client;

// MAAC defines the contract; your app owns the execution.
$maac->registerTool('${fn}', function (array $args, Context $ctx) {
    // 1. Enforce the caller's permissions
    if (! $ctx->user->can('${tool.id.replace(/^get/, "").toLowerCase()}:read')) {
        return ['status' => 'rejected', 'reason' => 'Not permitted'];
    }

    // 2. Query YOUR application's own data
    $data = AppData::query([
${argList.map(a => `        '${a}' => $args['${a}'] ?? null,`).join("\n")}
    ]);

    // 3. Return a result matching the output schema
    return ['summary' => $data->summary, 'records' => $data->records];
});`,
    py:`from maac import maac, Context

# MAAC defines the contract; your app owns the execution.
@maac.tool("${fn}")
async def ${tool.id}(args: dict, ctx: Context):
    # 1. Enforce the caller's permissions
    if not ctx.user.has_permission("${tool.id.replace(/^get/, "").toLowerCase()}:read"):
        return {"status": "rejected", "reason": "Not permitted"}

    # 2. Query YOUR application's own data
    data = await db.query(
${argList.map(a => `        ${a}=args.get("${a}"),`).join("\n")}
    )

    # 3. Return a result matching the output schema
    return {"summary": data.summary, "records": data.records}`,
  };
  return (
    <Card pad={false}>
      <div style={{ padding:"13px 16px 12px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <SectionHeader title="Generated SDK stub" sub="Copy into the owning application to implement this tool" icon="code" style={{ marginBottom:0 }} />
        <Segmented options={[{ value:"ts", label:"TypeScript" }, { value:"php", label:"PHP / Laravel" }, { value:"py", label:"Python" }]} value={lang} onChange={setLang} size="sm" />
      </div>
      <CodeBlock code={stubs[lang]} lang={lang === "ts" ? "typescript" : lang === "php" ? "php" : "python"} style={{ border:"none", borderRadius:0 }} maxHeight={340} />
    </Card>
  );
}

Object.assign(window, { Tools, ToolDetail, Timeline, schemaJson, SDKStubs });
