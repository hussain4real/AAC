/* ============================================================
   MAAC — Tweaks mount (light/dark + accent lead + density)
   ============================================================ */
const MAAC_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "purple",
  "density": "compact"
}/*EDITMODE-END*/;

function TweaksMount({ theme, setTheme }) {
  const [t, setTweak] = useTweaks(MAAC_TWEAK_DEFAULTS);

  // accent
  useEffect(() => {
    document.documentElement.setAttribute("data-accent", t.accent);
  }, [t.accent]);

  // density -> tune base font + row padding via a class on <html>
  useEffect(() => {
    document.documentElement.setAttribute("data-density", t.density);
  }, [t.density]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Appearance" />
      <TweakToggle label="Dark mode" value={theme === "dark"} onChange={v => setTheme(v ? "dark" : "light")} />
      <TweakColor label="Accent lead" value={ACCENT_SWATCH[t.accent]}
        options={[ACCENT_SWATCH.purple, ACCENT_SWATCH.navy, ACCENT_SWATCH.teal]}
        onChange={v => setTweak("accent", SWATCH_TO_ACCENT[v] || "purple")} />
      <TweakSection label="Layout" />
      <TweakRadio label="Density" value={t.density} options={["compact", "comfy"]}
        onChange={v => setTweak("density", v)} />
    </TweaksPanel>
  );
}

const ACCENT_SWATCH = { purple:"#5C0F8C", navy:"#1f4d8f", teal:"#0f8f78" };
const SWATCH_TO_ACCENT = { "#5C0F8C":"purple", "#1f4d8f":"navy", "#0f8f78":"teal" };

/* density CSS */
(function injectTweakCSS() {
  if (document.getElementById("maac-tweak-css")) return;
  const css = `
  :root[data-density="comfy"]{ font-size:13.5px }
  :root[data-density="comfy"] td{ padding-top:13px !important; padding-bottom:13px !important }
  :root[data-density="comfy"] th{ padding-top:11px !important; padding-bottom:11px !important }
  `;
  const s = document.createElement("style");
  s.id = "maac-tweak-css";
  s.textContent = css;
  document.head.appendChild(s);
})();

window.TweaksMount = TweaksMount;
