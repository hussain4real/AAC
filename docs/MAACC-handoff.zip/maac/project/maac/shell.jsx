/* ============================================================
   MAAC — App shell (sidebar, topbar, nav context, global CSS)
   ============================================================ */

/* ---- inject interaction CSS ---- */
(function injectCSS() {
  if (document.getElementById("maac-runtime-css")) return;
  const css = `
  .maac-btn:hover:not(:disabled){ filter:brightness(.97) }
  :root[data-theme="dark"] .maac-btn:hover:not(:disabled){ filter:brightness(1.12) }
  .maac-btn:active:not(:disabled){ transform:translateY(.5px) }
  .maac-card-hover:hover{ box-shadow:var(--sh-md); border-color:var(--border-2); transform:translateY(-1px) }
  .maac-row:hover{ background:var(--surface-2) }
  .maac-link{ cursor:pointer; transition:color .12s }
  .maac-link:hover{ color:var(--primary) !important; text-decoration:none }
  .maac-input:focus{ border-color:var(--primary) !important; box-shadow:0 0 0 3px var(--ring) }
  .maac-iconbtn:hover{ background:var(--surface-3); color:var(--text) !important }
  .maac-copybtn:hover{ background:var(--surface-3) }
  .maac-hbar:hover{ opacity:.85 }
  .maac-navitem{ transition:background .12s, color .12s }
  .maac-navitem:hover{ background:rgba(255,255,255,.06); color:#fff }
  .maac-vbar{ position:relative }
  .maac-tip{ position:relative }
  .maac-tip:hover::after, .maac-vbar:hover::after{
    content:attr(data-tip); position:absolute; bottom:calc(100% + 7px); left:50%; transform:translateX(-50%);
    background:var(--navy-900); color:#fff; font-size:11px; font-weight:500; padding:5px 8px; border-radius:6px;
    white-space:nowrap; z-index:50; pointer-events:none; box-shadow:var(--sh-pop); font-family:var(--font);
  }
  .maac-tip:hover::after{ font-size:11.5px; max-width:260px; white-space:normal; width:max-content; text-align:left; line-height:1.4 }
  .maac-scroll::-webkit-scrollbar{ width:8px }
  input::placeholder, textarea::placeholder{ color:var(--text-3) }
  @media (prefers-reduced-motion: reduce){ *{ animation-duration:.01ms !important; transition-duration:.01ms !important } }
  `;
  const s = document.createElement("style");
  s.id = "maac-runtime-css";
  s.textContent = css;
  document.head.appendChild(s);
})();

const NavContext = createContext(null);
const useNav = () => useContext(NavContext);

/* ---------- Nav definition ---------- */
const NAV_GROUPS = [
  { title:null, items:[{ id:"dashboard", label:"Dashboard", icon:"dashboard" }] },
  { title:"Build", items:[
    { id:"applications", label:"Applications", icon:"apps" },
    { id:"projects", label:"Projects", icon:"projects" },
    { id:"agents", label:"Agents", icon:"agents" },
    { id:"tools", label:"Tools", icon:"tools" },
  ]},
  { title:"Integrate", items:[
    { id:"sdk", label:"SDK Implementation", icon:"sdk" },
    { id:"playground", label:"Agent Playground", icon:"playground" },
  ]},
  { title:"Operate", items:[
    { id:"runs", label:"Runs & Audit Logs", icon:"runs" },
    { id:"llm", label:"LLM Providers", icon:"llm" },
  ]},
  { title:"Govern", items:[
    { id:"governance", label:"Governance", icon:"governance" },
    { id:"settings", label:"Settings", icon:"settings" },
  ]},
];
const SCREEN_OF = {
  dashboard:"dashboard", applications:"applications", application:"applications",
  projects:"projects", agents:"agents", agent:"agents", createAgent:"agents",
  tools:"tools", tool:"tools", sdk:"sdk", playground:"playground",
  runs:"runs", run:"runs", llm:"llm", governance:"governance", settings:"settings",
};

/* ---------- Personas / role-based views ---------- */
const PERSONAS = [
  { id:"admin", name:"Layla Hassan", role:"MAAC Admin", view:"Admin view", short:"Admin",
    blurb:"Full platform access — every application, project, agent, tool, run and governance queue.",
    scope:"all", tone:"var(--purple-600)" },
  { id:"projadmin", name:"Khalid Al-Mansoori", role:"Project Admin", view:"Project view", short:"Project",
    blurb:"Owns the Marine Operations Portal — sees all agents & tools across its projects.",
    scope:"projects", appIds:["MOP"], projectIds:["prj_mop_ops","prj_mop_berth","prj_mop_docs"], tone:"var(--teal-500)" },
  { id:"dev", name:"Reema Saleh", role:"Agent Developer", view:"Developer view", short:"Developer",
    blurb:"Member of 2 projects — sees only the agents & tools inside those projects.",
    scope:"member", projectIds:["prj_mop_ops","prj_fws_appr"], tone:"var(--blue-500)" },
];
const ROLE_ALLOWED = {
  admin: null, // all nav
  projadmin: ["dashboard","applications","projects","agents","tools","sdk","playground","runs","governance","settings"],
  dev: ["dashboard","projects","agents","tools","sdk","playground","runs","settings"],
};
function navAllowed(personaId, navId) { const a = ROLE_ALLOWED[personaId]; return !a || a.includes(navId); }

function computeScope(persona) {
  const M = window.MAAC;
  if (!persona || persona.scope === "all") {
    return { isAll:true, role:persona, apps:M.apps, projects:M.projects, agents:M.agents, tools:M.tools, runs:M.runs,
      has:{ app:() => true, project:() => true, agent:() => true, tool:() => true, run:() => true } };
  }
  const projIds = new Set(persona.projectIds || []);
  const projects = M.projects.filter(p => projIds.has(p.id));
  const appIds = new Set([...(persona.appIds || []), ...projects.map(p => p.appId)]);
  const apps = M.apps.filter(a => appIds.has(a.id));
  const agents = M.agents.filter(a => projIds.has(a.projectId));
  const agentIds = new Set(agents.map(a => a.id));
  const tools = M.tools.filter(t => t.scope === "Global" || t.usedBy.some(u => agentIds.has(u)));
  const toolIds = new Set(tools.map(t => t.id));
  const runs = M.runs.filter(r => agentIds.has(r.agentId));
  return { isAll:false, role:persona, apps, projects, agents, tools, runs, appIds, projIds, agentIds,
    has:{ app:id => appIds.has(id), project:id => projIds.has(id), agent:id => agentIds.has(id),
      tool:id => toolIds.has(id), run:id => runs.some(r => r.id === id) } };
}

/* ---------- Logo ---------- */
function Logo({ compact = false }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:11 }}>
      <div style={{ width:34, height:34, borderRadius:9, background:"linear-gradient(145deg, var(--purple-500), var(--navy-900))", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, boxShadow:"0 2px 8px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.14)", position:"relative", overflow:"hidden" }}>
        <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
          <path d="M5 12h11M13 7l5 5-5 5" stroke="var(--orange-600)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      {!compact && (
        <div style={{ lineHeight:1 }}>
          <div style={{ fontSize:16, fontWeight:700, color:"#fff", letterSpacing:.3 }}>Milaha</div>
          <div style={{ fontSize:9.5, fontWeight:600, color:"rgba(255,255,255,.5)", letterSpacing:1.4, marginTop:3, textTransform:"uppercase" }}>AI Agent Center</div>
        </div>
      )}
    </div>
  );
}

/* ---------- Sidebar ---------- */
function Sidebar() {
  const { nav, go, persona, setPersona } = useNav();
  const activeScreen = SCREEN_OF[nav.name] || nav.name;
  const [acctOpen, setAcctOpen] = useState(false);
  const visibleGroups = NAV_GROUPS
    .map(g => ({ ...g, items: g.items.filter(it => navAllowed(persona.id, it.id)) }))
    .filter(g => g.items.length);
  return (
    <aside style={{ width:"var(--sidebar-w)", flexShrink:0, background:"linear-gradient(180deg, #061731, #04122a 60%, #050d1e)", display:"flex", flexDirection:"column", borderRight:"1px solid rgba(255,255,255,.06)", position:"relative", zIndex:10 }}>
      <div style={{ padding:"16px 16px 12px" }}>
        <Logo />
      </div>

      {/* account / persona switcher (top-left) */}
      <div style={{ padding:"0 12px 10px", position:"relative" }}>
        <button onMouseDown={e => e.stopPropagation()} onClick={() => setAcctOpen(o => !o)} style={{ width:"100%", display:"flex", alignItems:"center", gap:10, padding:"8px 10px", borderRadius:10, border:"1px solid rgba(255,255,255,.1)", background:acctOpen ? "rgba(255,255,255,.08)" : "rgba(255,255,255,.04)", cursor:"pointer", transition:"background .12s" }} className="maac-navitem">
          <Avatar name={persona.name} size={32} tone={persona.tone} />
          <div style={{ flex:1, minWidth:0, textAlign:"left", lineHeight:1.25 }}>
            <div style={{ fontSize:12.5, fontWeight:700, color:"#fff", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{persona.name}</div>
            <div style={{ fontSize:10.5, color:"rgba(255,255,255,.55)", display:"flex", alignItems:"center", gap:5 }}>
              <span style={{ width:6, height:6, borderRadius:6, background:persona.tone }} />{persona.role}
            </div>
          </div>
          <Icon name="chevdown" size={15} style={{ color:"rgba(255,255,255,.5)", transform:acctOpen ? "rotate(180deg)" : "none", transition:"transform .15s" }} />
        </button>
        {acctOpen && <AccountSwitcher persona={persona} setPersona={p => { setPersona(p); setAcctOpen(false); }} onClose={() => setAcctOpen(false)} />}
      </div>

      <div style={{ padding:"0 12px 8px" }}>
        <button onClick={() => go("createAgent")} style={{ width:"100%", height:36, borderRadius:8, border:"1px solid rgba(255,255,255,.12)", background:"rgba(255,255,255,.04)", color:"#fff", fontSize:12.5, fontWeight:600, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:7, transition:"background .12s" }} className="maac-navitem">
          <Icon name="plus" size={15} strokeWidth={2.2} /> New Agent
        </button>
      </div>
      <nav className="maac-scroll" style={{ flex:1, overflowY:"auto", padding:"6px 12px 14px" }}>
        {visibleGroups.map((grp, gi) => (
          <div key={gi} style={{ marginBottom:14 }}>
            {grp.title && <div style={{ fontSize:10, fontWeight:700, color:"rgba(255,255,255,.34)", textTransform:"uppercase", letterSpacing:1, padding:"6px 10px 5px" }}>{grp.title}</div>}
            <div style={{ display:"flex", flexDirection:"column", gap:1 }}>
              {grp.items.map(it => {
                const on = activeScreen === it.id;
                return (
                  <button key={it.id} onClick={() => go(it.id)} className="maac-navitem" style={{
                    display:"flex", alignItems:"center", gap:11, padding:"8px 10px", borderRadius:7,
                    border:"none", cursor:"pointer", fontSize:13, fontWeight:on ? 600 : 500, textAlign:"left",
                    background:on ? "linear-gradient(90deg, rgba(123,46,174,.45), rgba(123,46,174,.16))" : "transparent",
                    color:on ? "#fff" : "rgba(255,255,255,.62)", position:"relative" }}>
                    {on && <span style={{ position:"absolute", left:0, top:7, bottom:7, width:3, borderRadius:3, background:"var(--orange-600)" }} />}
                    <Icon name={it.icon} size={17} strokeWidth={on ? 2 : 1.7} style={{ color:on ? "var(--orange-400)" : "rgba(255,255,255,.5)" }} />
                    {it.label}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
      <div style={{ padding:"12px 16px", borderTop:"1px solid rgba(255,255,255,.07)", display:"flex", alignItems:"center", gap:10 }}>
        <span style={{ width:8, height:8, borderRadius:8, background:"var(--teal-400)", boxShadow:"0 0 0 3px rgba(60,191,174,.2)" }} />
        <div style={{ fontSize:11, color:"rgba(255,255,255,.55)", lineHeight:1.3 }}>
          <div style={{ color:"rgba(255,255,255,.8)", fontWeight:600 }}>All systems operational</div>
          <div>MAAC v1.1 · Doha DC</div>
        </div>
      </div>
    </aside>
  );
}

function AccountSwitcher({ persona, setPersona, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    const id = setTimeout(() => document.addEventListener("mousedown", h), 0);
    return () => { clearTimeout(id); document.removeEventListener("mousedown", h); };
  }, []);
  return (
    <div ref={ref} onClick={e => e.stopPropagation()} style={{ position:"absolute", top:"calc(100% - 2px)", left:12, right:12, zIndex:80, background:"var(--surface)", border:"1px solid var(--border)", borderRadius:"var(--r-lg)", boxShadow:"var(--sh-pop)", overflow:"hidden" }}>
      <div style={{ padding:"10px 13px 8px", borderBottom:"1px solid var(--border)", display:"flex", alignItems:"center", gap:7 }}>
        <Icon name="eye" size={14} style={{ color:"var(--text-3)" }} />
        <span style={{ fontSize:11, fontWeight:700, color:"var(--text-3)", textTransform:"uppercase", letterSpacing:.5 }}>Switch view</span>
      </div>
      <div style={{ padding:6 }}>
        {PERSONAS.map(p => {
          const on = p.id === persona.id;
          return (
            <button key={p.id} onClick={() => setPersona(p)} className="maac-row" style={{ width:"100%", display:"flex", gap:11, padding:"10px 10px", border:"none", background:on ? "var(--primary-soft)" : "none", borderRadius:9, cursor:"pointer", textAlign:"left", alignItems:"flex-start" }}>
              <Avatar name={p.name} size={32} tone={p.tone} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:"flex", alignItems:"center", gap:7 }}>
                  <span style={{ fontSize:13, fontWeight:700, color:"var(--text)" }}>{p.name}</span>
                  {on && <Badge tone="purple" soft>Active</Badge>}
                </div>
                <div style={{ fontSize:11, fontWeight:600, color:p.tone, marginTop:1 }}>{p.role}</div>
                <div style={{ fontSize:11, color:"var(--text-3)", marginTop:4, lineHeight:1.45 }}>{p.blurb}</div>
              </div>
            </button>
          );
        })}
      </div>
      <div style={{ padding:"8px 6px", borderTop:"1px solid var(--border)" }}>
        <button className="maac-row" style={{ width:"100%", display:"flex", alignItems:"center", gap:10, padding:"8px 10px", border:"none", background:"none", cursor:"pointer", borderRadius:7, fontSize:12.5, color:"var(--red-600)", textAlign:"left" }}>
          <Icon name="power" size={15} /> Sign out
        </button>
      </div>
    </div>
  );
}

/* ---------- Topbar ---------- */
function Topbar({ theme, setTheme, env, setEnv }) {
  const { go, persona } = useNav();
  const [notifOpen, setNotifOpen] = useState(false);
  return (
    <header style={{ height:56, flexShrink:0, background:"var(--surface)", borderBottom:"1px solid var(--border)", display:"flex", alignItems:"center", gap:14, padding:"0 20px", position:"relative", zIndex:30 }}>
      <div style={{ position:"relative", flex:1, maxWidth:420 }}>
        <Icon name="search" size={15} style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", color:"var(--text-3)" }} />
        <input placeholder="Search agents, tools, applications, runs…" className="maac-input"
          style={{ ...inputStyle, height:36, paddingLeft:34, background:"var(--surface-2)", border:"1px solid var(--border)" }} />
        <span style={{ position:"absolute", right:9, top:"50%", transform:"translateY(-50%)", fontSize:11, fontWeight:600, color:"var(--text-3)", border:"1px solid var(--border-2)", borderRadius:5, padding:"1px 6px", fontFamily:"var(--mono)" }}>⌘K</span>
      </div>
      <div style={{ flex:1 }} />
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
        <span className="maac-tip" data-tip={persona.blurb} style={{ display:"inline-flex", alignItems:"center", gap:7, height:32, padding:"0 11px", borderRadius:999, border:`1px solid ${persona.tone}`, background:"var(--surface-2)", fontSize:12, fontWeight:600, color:"var(--text)", cursor:"help" }}>
          <span style={{ width:7, height:7, borderRadius:7, background:persona.tone }} />{persona.view}
        </span>
        <Select value={env} onChange={setEnv} options={[{ value:"Production", label:"⬤ Production" }, { value:"Staging", label:"⬤ Staging" }, { value:"Development", label:"⬤ Development" }]} style={{ width:150 }} />
        <button onClick={() => setTheme(theme === "light" ? "dark" : "light")} className="maac-iconbtn" style={{ width:36, height:36, borderRadius:8, border:"1px solid var(--border)", background:"var(--surface-2)", color:"var(--text-2)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }} title="Toggle theme">
          <Icon name={theme === "light" ? "moon" : "sun"} size={17} />
        </button>
        <div style={{ position:"relative" }}>
          <button onMouseDown={e => e.stopPropagation()} onClick={() => setNotifOpen(!notifOpen)} className="maac-iconbtn" style={{ width:36, height:36, borderRadius:8, border:"1px solid var(--border)", background:"var(--surface-2)", color:"var(--text-2)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
            <Icon name="bell" size={17} />
            <span style={{ position:"absolute", top:7, right:8, width:7, height:7, borderRadius:7, background:"var(--orange-600)", border:"2px solid var(--surface)" }} />
          </button>
          {notifOpen && <NotifMenu onClose={() => setNotifOpen(false)} go={go} />}
        </div>
      </div>
    </header>
  );
}

function NotifMenu({ onClose, go }) {
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    const id = setTimeout(() => document.addEventListener("mousedown", h), 0);
    return () => { clearTimeout(id); document.removeEventListener("mousedown", h); };
  }, []);
  return (
    <div ref={ref} onClick={e => e.stopPropagation()} style={{ position:"absolute", top:46, right:0, width:340, background:"var(--surface)", border:"1px solid var(--border)", borderRadius:"var(--r-lg)", boxShadow:"var(--sh-pop)", zIndex:60, overflow:"hidden" }}>
      <div style={{ padding:"12px 14px", borderBottom:"1px solid var(--border)", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <span style={{ fontSize:13, fontWeight:700 }}>Notifications</span>
        <Badge tone="orange">4 new</Badge>
      </div>
      <div style={{ maxHeight:340, overflowY:"auto" }}>
        {MAAC.dashboard.alerts.map((a, i) => (
          <div key={i} onClick={() => { go("governance"); onClose(); }} className="maac-row" style={{ display:"flex", gap:10, padding:"11px 14px", borderBottom:"1px solid var(--border)", cursor:"pointer" }}>
            <span style={{ width:28, height:28, borderRadius:7, flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", background:a.sev === "high" ? "var(--red-100)" : a.sev === "med" ? "var(--orange-100)" : "var(--primary-soft)", color:a.sev === "high" ? "var(--red-600)" : a.sev === "med" ? "var(--orange-600)" : "var(--primary)" }}><Icon name={a.icon} size={15} /></span>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:12.5, fontWeight:600 }}>{a.title}</div>
              <div style={{ fontSize:11.5, color:"var(--text-3)", marginTop:1 }}>{a.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
function UserMenu({ onClose, go }) {
  useEffect(() => { const h = () => onClose(); window.addEventListener("click", h); return () => window.removeEventListener("click", h); }, []);
  const items = [{ icon:"user", label:"Profile" }, { icon:"settings", label:"Settings", go:"settings" }, { icon:"shield", label:"Governance", go:"governance" }, { icon:"book", label:"Documentation" }];
  return (
    <div onClick={e => e.stopPropagation()} style={{ position:"absolute", top:50, right:0, width:210, background:"var(--surface)", border:"1px solid var(--border)", borderRadius:"var(--r-lg)", boxShadow:"var(--sh-pop)", zIndex:60, animation:"popIn .15s ease", padding:6 }}>
      {items.map((it, i) => (
        <button key={i} onClick={() => { if (it.go) go(it.go); onClose(); }} className="maac-row" style={{ width:"100%", display:"flex", alignItems:"center", gap:10, padding:"8px 10px", border:"none", background:"none", cursor:"pointer", borderRadius:7, fontSize:13, color:"var(--text-2)", textAlign:"left" }}>
          <Icon name={it.icon} size={16} /> {it.label}
        </button>
      ))}
      <div style={{ height:1, background:"var(--border)", margin:"5px 4px" }} />
      <button className="maac-row" style={{ width:"100%", display:"flex", alignItems:"center", gap:10, padding:"8px 10px", border:"none", background:"none", cursor:"pointer", borderRadius:7, fontSize:13, color:"var(--red-600)", textAlign:"left" }}>
        <Icon name="power" size={16} /> Sign out
      </button>
    </div>
  );
}

Object.assign(window, { NavContext, useNav, Sidebar, Topbar, Logo, NAV_GROUPS, SCREEN_OF, PERSONAS, ROLE_ALLOWED, navAllowed, computeScope });
