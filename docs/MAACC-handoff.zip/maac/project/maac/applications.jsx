/* ============================================================
   MAAC — Applications (list + detail)
   ============================================================ */
function Applications() {
  const { go, scope } = useNav();
  const [view, setView] = useState("grid");
  const [q, setQ] = useState("");
  const [dept, setDept] = useState("All departments");
  const [showReg, setShowReg] = useState(false);

  const depts = ["All departments", ...Array.from(new Set(scope.apps.map(a => a.dept)))];
  const list = scope.apps.filter(a =>
    (dept === "All departments" || a.dept === dept) &&
    (a.name.toLowerCase().includes(q.toLowerCase()) || a.code.includes(q.toLowerCase())));

  return (
    <div className="route-anim">
      <PageHeader title="Applications" sub="Company systems registered with MAAC. Each receives credentials and implements its own client-side tools through the SDK."
        actions={<Btn variant="primary" icon="plus" onClick={() => setShowReg(true)}>Register Application</Btn>} />

      <div style={{ display:"flex", gap:9, marginBottom:14, alignItems:"center", flexWrap:"wrap" }}>
        <div style={{ position:"relative", width:280 }}>
          <Icon name="search" size={15} style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", color:"var(--text-3)" }} />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search applications…" className="maac-input" style={{ ...inputStyle, paddingLeft:34 }} />
        </div>
        <Select value={dept} onChange={setDept} options={depts} style={{ width:200 }} />
        <div style={{ flex:1 }} />
        <Segmented options={[{ value:"grid", icon:"grid" }, { value:"list", icon:"list" }]} value={view} onChange={setView} />
      </div>

      {list.length === 0 && <Card><EmptyState icon="apps" title="No applications found" desc="Try a different search or department filter." /></Card>}

      {view === "grid" && list.length > 0 && (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(380px, 1fr))", gap:12 }}>
          {list.map(a => <AppCard key={a.id} app={a} onOpen={() => go("application", { id:a.id })} />)}
        </div>
      )}

      {view === "list" && list.length > 0 && (
        <Table columns={[{ label:"Application" }, { label:"Department" }, { label:"Env" }, { label:"Status" }, { label:"Projects", align:"right" }, { label:"Agents", align:"right" }, { label:"Client tools", align:"center" }, { label:"Last connected", align:"right" }]}>
          {list.map(a => (
            <Tr key={a.id} onClick={() => go("application", { id:a.id })}>
              <Td strong><div style={{ display:"flex", alignItems:"center", gap:10 }}><AppMark code={a.id} /><div><div style={{ color:"var(--text)", fontWeight:600 }}>{a.name}</div><div className="mono" style={{ fontSize:11, color:"var(--text-3)" }}>{a.code}</div></div></div></Td>
              <Td>{a.dept}</Td>
              <Td><EnvBadge env={a.env} /></Td>
              <Td><Badge tone={APP_STATUS[a.status].tone} dot>{a.status}</Badge></Td>
              <Td align="right" mono strong>{a.projects}</Td>
              <Td align="right" mono strong>{a.agents}</Td>
              <Td align="center"><ToolMeter req={a.toolsRequired} done={a.toolsImplemented} /></Td>
              <Td align="right" style={{ color:"var(--text-3)" }}>{a.lastConnected}</Td>
            </Tr>
          ))}
        </Table>
      )}

      <RegisterAppModal open={showReg} onClose={() => setShowReg(false)} />
    </div>
  );
}

function AppMark({ code, size = 34 }) {
  const colors = { MOP:"var(--purple-600)", FWS:"var(--teal-500)", PMA:"var(--orange-600)", CSP:"var(--blue-500)", VMS:"var(--navy-700)" };
  return <div style={{ width:size, height:size, borderRadius:8, background:colors[code] || "var(--purple-600)", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:size * .34, fontWeight:700, flexShrink:0, fontFamily:"var(--mono)" }}>{code}</div>;
}

function ToolMeter({ req, done }) {
  const pct = req ? (done / req) * 100 : 100;
  const tone = pct === 100 ? "var(--teal-500)" : pct >= 50 ? "var(--orange-600)" : "var(--red-500)";
  return (
    <div className="maac-tip" data-tip={`${done} of ${req} client-side tools implemented`} style={{ display:"inline-flex", alignItems:"center", gap:7 }}>
      <div style={{ width:46, height:6, background:"var(--track)", borderRadius:999, overflow:"hidden" }}><div style={{ height:"100%", width:`${pct}%`, background:tone }} /></div>
      <span className="tnum mono" style={{ fontSize:11.5, fontWeight:600, color:"var(--text-2)" }}>{done}/{req}</span>
    </div>
  );
}

function AppCard({ app, onOpen }) {
  return (
    <Card hover onClick={onOpen} style={{ padding:0, overflow:"hidden", display:"flex", flexDirection:"column" }}>
      <div style={{ padding:"15px 16px", display:"flex", gap:12, alignItems:"flex-start" }}>
        <AppMark code={app.id} size={40} />
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, justifyContent:"space-between" }}>
            <span style={{ fontSize:14.5, fontWeight:700, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{app.name}</span>
            <Badge tone={APP_STATUS[app.status].tone} dot>{app.status}</Badge>
          </div>
          <div className="mono" style={{ fontSize:11.5, color:"var(--text-3)", marginTop:2 }}>{app.code}</div>
        </div>
      </div>
      <div style={{ padding:"0 16px 12px", fontSize:12.5, color:"var(--text-2)", lineHeight:1.5 }}>{app.desc}</div>
      <div style={{ display:"flex", gap:8, padding:"0 16px 13px", flexWrap:"wrap" }}>
        <Badge tone="neutral" icon="building">{app.dept}</Badge>
        <EnvBadge env={app.env} />
      </div>
      <div style={{ marginTop:"auto", display:"grid", gridTemplateColumns:"repeat(3,1fr)", borderTop:"1px solid var(--border)", background:"var(--surface-2)" }}>
        <Stat3 label="Projects" value={app.projects} />
        <Stat3 label="Agents" value={app.agents} border />
        <Stat3 label="Tools" value={<ToolMeter req={app.toolsRequired} done={app.toolsImplemented} />} border />
      </div>
    </Card>
  );
}
function Stat3({ label, value, border }) {
  return (
    <div style={{ padding:"10px 14px", borderLeft:border ? "1px solid var(--border)" : "none" }}>
      <div style={{ fontSize:10.5, color:"var(--text-3)", fontWeight:600, textTransform:"uppercase", letterSpacing:.3 }}>{label}</div>
      <div className="tnum" style={{ fontSize:15, fontWeight:700, marginTop:2 }}>{value}</div>
    </div>
  );
}

function RegisterAppModal({ open, onClose }) {
  const [name, setName] = useState("");
  return (
    <Modal open={open} onClose={onClose} icon="apps" title="Register Application" sub="Create a new application and generate environment credentials."
      footer={<><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="primary" icon="check" onClick={onClose}>Register & Generate Credentials</Btn></>}>
      <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
        <Field label="Application name" required><Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Marine Operations Portal" /></Field>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
          <Field label="Application code" required hint="Lowercase, hyphenated identifier"><Input placeholder="marine-ops-portal" /></Field>
          <Field label="Environment" required><Select value="Production" onChange={() => {}} options={["Production", "Staging", "Development"]} /></Field>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
          <Field label="Owning department" required><Select value="Maritime & Logistics" onChange={() => {}} options={["Maritime & Logistics", "Finance", "Procurement", "Customer Experience", "Marine & Technical Services"]} /></Field>
          <Field label="Technical owner" required><Input placeholder="name@milaha.com" /></Field>
        </div>
        <Field label="Description"><Textarea rows={3} placeholder="What does this application do?" /></Field>
        <div style={{ display:"flex", gap:10, padding:"11px 13px", background:"var(--primary-soft)", borderRadius:"var(--r-md)", border:"1px solid var(--primary-soft-2)" }}>
          <Icon name="info" size={17} style={{ color:"var(--primary)", flexShrink:0, marginTop:1 }} />
          <div style={{ fontSize:12, color:"var(--text-2)", lineHeight:1.5 }}>On registration, MAAC generates a <b>Client ID</b> and <b>Client Secret</b> scoped to this environment. The application installs the MAAC SDK and configures these credentials to connect.</div>
        </div>
      </div>
    </Modal>
  );
}

/* ============================ DETAIL ============================ */
function ApplicationDetail({ id }) {
  const { go, back, scope } = useNav();
  const app = MAAC.appById(id);
  const [tab, setTab] = useState("overview");
  if (!app) return <PlaceholderScreen name="Application" />;
  if (!scope.has.app(id)) return <NoAccess kind="application" />;

  const appAgents = MAAC.agentsByApp(id);
  const appProjects = MAAC.projectsByApp(id);
  const appTools = MAAC.tools.filter(t => t.appId === id);

  const tabs = [
    { id:"overview", label:"Overview", icon:"dashboard" },
    { id:"projects", label:"Projects", icon:"projects", count:appProjects.length },
    { id:"agents", label:"Agents", icon:"agents", count:appAgents.length },
    { id:"tools", label:"Required Tools", icon:"tools", count:appTools.length },
    { id:"creds", label:"Credentials", icon:"key" },
    { id:"history", label:"Run History", icon:"runs" },
    { id:"sdk", label:"SDK Setup", icon:"sdk" },
  ];

  return (
    <div className="route-anim">
      <PageHeader
        breadcrumb={[{ label:"Applications", onClick:() => go("applications") }, { label:app.name }]}
        title={<span style={{ display:"inline-flex", alignItems:"center", gap:12 }}><AppMark code={app.id} size={32} />{app.name}</span>}
        badge={<><Badge tone={APP_STATUS[app.status].tone} dot>{app.status}</Badge><EnvBadge env={app.env} /></>}
        sub={app.desc}
        actions={<>
          <Btn variant="default" icon="key" onClick={() => setTab("creds")}>Manage Credentials</Btn>
          {app.status === "Active"
            ? <Btn variant="danger" icon="power">Suspend</Btn>
            : <Btn variant="primary" icon="power">Activate</Btn>}
        </>}
        tabs={<Tabs tabs={tabs} active={tab} onChange={setTab} />}
      />

      {tab === "overview" && <AppOverview app={app} agents={appAgents} projects={appProjects} tools={appTools} go={go} setTab={setTab} />}
      {tab === "projects" && <AppProjects app={app} projects={appProjects} go={go} />}
      {tab === "agents" && <AppAgents agents={appAgents} go={go} />}
      {tab === "tools" && <AppTools tools={appTools} go={go} />}
      {tab === "creds" && <AppCreds app={app} />}
      {tab === "history" && <AppHistory app={app} go={go} />}
      {tab === "sdk" && <AppSDK app={app} />}
    </div>
  );
}

function AppOverview({ app, agents, projects, tools, go, setTab }) {
  const missing = tools.filter(t => ["required", "outdated", "incompatible"].includes(t.impl));
  const implemented = tools.filter(t => t.impl === "implemented");
  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 320px", gap:14 }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <Card>
          <SectionHeader title="Application metadata" icon="info" />
          <KV cols={3} items={[
            { k:"Application code", v:app.code, mono:true },
            { k:"Owning department", v:app.dept },
            { k:"Environment", v:<EnvBadge env={app.env} /> },
            { k:"Technical owner", v:app.owner },
            { k:"Owner email", v:app.ownerEmail, mono:true },
            { k:"Tech stack", v:app.stack },
            { k:"Region", v:app.region },
            { k:"Registered", v:app.created },
            { k:"Last connected", v:app.lastConnected },
          ]} />
        </Card>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
          <Card>
            <SectionHeader title="Client-side tools implemented" icon="check2" right={<Badge tone="teal">{implemented.length}/{tools.length}</Badge>} />
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {implemented.length === 0 && <div style={{ fontSize:12.5, color:"var(--text-3)" }}>None implemented yet.</div>}
              {implemented.map(t => (
                <div key={t.id} className="maac-row" onClick={() => go("tool", { id:t.id })} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"7px 9px", borderRadius:7, cursor:"pointer" }}>
                  <span className="mono" style={{ fontSize:12 }}>{t.name}</span><Icon name="check" size={15} style={{ color:"var(--teal-600)" }} />
                </div>
              ))}
            </div>
          </Card>
          <Card style={{ borderColor:missing.length ? "var(--orange-400)" : "var(--border)" }}>
            <SectionHeader title="Tools missing implementation" icon="alert" right={<Badge tone="orange">{missing.length}</Badge>} />
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {missing.length === 0 && <div style={{ fontSize:12.5, color:"var(--text-3)" }}>All tools implemented 🎉</div>}
              {missing.map(t => (
                <div key={t.id} className="maac-row" onClick={() => go("tool", { id:t.id })} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"7px 9px", borderRadius:7, cursor:"pointer" }}>
                  <span className="mono" style={{ fontSize:12 }}>{t.name}</span><ImplBadge status={t.impl} />
                </div>
              ))}
            </div>
            {missing.length > 0 && <Btn variant="soft" size="sm" full style={{ marginTop:12 }} iconRight="arrowRight" onClick={() => go("sdk")}>Open SDK Implementation Center</Btn>}
          </Card>
        </div>

        <Card pad={false}>
          <div style={{ padding:"14px 16px 12px" }}><SectionHeader title="Published agents" icon="agents" style={{ marginBottom:0 }} right={<Btn variant="ghost" size="sm" onClick={() => setTab("agents")} iconRight="arrowRight">All agents</Btn>} /></div>
          <Table columns={[{ label:"Agent" }, { label:"LLM" }, { label:"Status" }, { label:"Success", align:"right" }, { label:"Runs 7d", align:"right" }]}>
            {agents.slice(0, 4).map(a => (
              <Tr key={a.id} onClick={() => go("agent", { id:a.id })}>
                <Td strong>{a.name}</Td>
                <Td mono>{MAAC.llmById(a.llm)?.name}</Td>
                <Td><AgentBadge status={a.status} /></Td>
                <Td align="right" mono>{a.successRate ? a.successRate + "%" : "—"}</Td>
                <Td align="right" mono>{a.runs7d.toLocaleString()}</Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>

      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <Card>
          <SectionHeader title="Connection status" icon="link" />
          <div style={{ display:"flex", flexDirection:"column", gap:11 }}>
            <StatusRow label="SDK connection" ok={app.status === "Active"} okText="Connected" badText="Disconnected" sub={`Last seen ${app.lastConnected}`} />
            <StatusRow label="API credentials" ok={app.credStatus === "Active"} okText="Active" badText={app.credStatus} sub="Client ID + Secret" />
            <StatusRow label="Tool sync" ok={app.toolsImplemented === app.toolsRequired} okText="In sync" badText={`${app.toolsRequired - app.toolsImplemented} pending`} sub="Client-side handlers" />
          </div>
        </Card>
        <Card>
          <SectionHeader title="At a glance" icon="grid" />
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
            <MiniStat label="Projects" value={projects.length} icon="projects" />
            <MiniStat label="Agents" value={agents.length} icon="agents" />
            <MiniStat label="Tools required" value={app.toolsRequired} icon="tools" />
            <MiniStat label="Implemented" value={app.toolsImplemented} icon="check2" tone="teal" />
          </div>
        </Card>
      </div>
    </div>
  );
}
function StatusRow({ label, ok, okText, badText, sub }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:11 }}>
      <span style={{ width:30, height:30, borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", background:ok ? "var(--teal-100)" : "var(--red-100)", color:ok ? "var(--teal-600)" : "var(--red-600)", flexShrink:0 }}><Icon name={ok ? "check2" : "alert"} size={16} /></span>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:12.5, fontWeight:600 }}>{label}</div>
        <div style={{ fontSize:11, color:"var(--text-3)" }}>{sub}</div>
      </div>
      <Badge tone={ok ? "teal" : "red"} dot>{ok ? okText : badText}</Badge>
    </div>
  );
}
function MiniStat({ label, value, icon, tone = "purple" }) {
  const t = TONES[tone];
  return (
    <div style={{ padding:"11px 12px", background:"var(--surface-2)", borderRadius:"var(--r-md)", border:"1px solid var(--border)" }}>
      <div style={{ display:"flex", alignItems:"center", gap:7, color:t.fg, marginBottom:5 }}><Icon name={icon} size={15} /></div>
      <div className="tnum" style={{ fontSize:20, fontWeight:700, lineHeight:1 }}>{value}</div>
      <div style={{ fontSize:11, color:"var(--text-3)", marginTop:3 }}>{label}</div>
    </div>
  );
}

function AppProjects({ projects, go }) {
  return (
    <Table columns={[{ label:"Project" }, { label:"Environment" }, { label:"Status" }, { label:"Agents", align:"right" }, { label:"Tools", align:"right" }, { label:"Runs 7d", align:"right" }]}>
      {projects.map(p => (
        <Tr key={p.id} onClick={() => go("projects")}>
          <Td strong><div>{p.name}<div style={{ fontSize:11.5, color:"var(--text-3)", fontWeight:400 }}>{p.desc}</div></div></Td>
          <Td><EnvBadge env={p.env} /></Td>
          <Td><Badge tone={p.status === "Active" ? "teal" : "neutral"} dot>{p.status}</Badge></Td>
          <Td align="right" mono>{p.agents}</Td>
          <Td align="right" mono>{p.tools}</Td>
          <Td align="right" mono>{p.runs7d.toLocaleString()}</Td>
        </Tr>
      ))}
    </Table>
  );
}
function AppAgents({ agents, go }) {
  return (
    <Table columns={[{ label:"Agent" }, { label:"LLM" }, { label:"Version" }, { label:"Status" }, { label:"Tools", align:"right" }, { label:"Success", align:"right" }, { label:"Last run", align:"right" }]}>
      {agents.map(a => (
        <Tr key={a.id} onClick={() => go("agent", { id:a.id })}>
          <Td strong>{a.name}</Td>
          <Td mono>{MAAC.llmById(a.llm)?.name}</Td>
          <Td mono>{a.version}</Td>
          <Td><AgentBadge status={a.status} /></Td>
          <Td align="right" mono>{a.tools.length}</Td>
          <Td align="right" mono>{a.successRate ? a.successRate + "%" : "—"}</Td>
          <Td align="right" style={{ color:"var(--text-3)" }}>{a.lastRun}</Td>
        </Tr>
      ))}
    </Table>
  );
}
function AppTools({ tools, go }) {
  return (
    <Table columns={[{ label:"Tool" }, { label:"Execution mode" }, { label:"Sensitivity" }, { label:"Used by" }, { label:"Status" }]}>
      {tools.map(t => (
        <Tr key={t.id} onClick={() => go("tool", { id:t.id })}>
          <Td strong mono>{t.name}</Td>
          <Td><ExecChip mode={t.execMode} /></Td>
          <Td><SensBadge level={t.sensitivity} /></Td>
          <Td>{t.usedBy.map(u => MAAC.agentById(u)?.name.replace(" Agent", "")).join(", ")}</Td>
          <Td><ImplBadge status={t.impl} /></Td>
        </Tr>
      ))}
    </Table>
  );
}

function AppCreds({ app }) {
  const [revealed, setRevealed] = useState(false);
  const secret = "msk_live_8f3a••••••••••••••••••••••••2b71";
  const fullSecret = "msk_live_8f3a91c4d2e7f60a3b85c19d2b71";
  const envBlock = `MAAC_PROJECT_ID=prj_${app.code.replace(/-/g, "_")}_${app.env.toLowerCase()}
MAAC_CLIENT_ID=cid_${app.id.toLowerCase()}_7d21
MAAC_CLIENT_SECRET=${revealed ? fullSecret : secret}
MAAC_ENVIRONMENT=${app.env.toLowerCase()}`;
  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 360px", gap:14 }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <Card>
          <SectionHeader title="API credentials" sub={`Scoped to ${app.name} · ${app.env}`} icon="key"
            right={<Badge tone={app.credStatus === "Active" ? "teal" : "red"} dot>{app.credStatus}</Badge>} />
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            <CredRow label="Client ID" value={`cid_${app.id.toLowerCase()}_7d21`} />
            <div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text-2)", marginBottom:6, display:"flex", justifyContent:"space-between" }}>
                <span>Client Secret</span>
                <button onClick={() => setRevealed(!revealed)} className="maac-link" style={{ border:"none", background:"none", cursor:"pointer", fontSize:11.5, fontWeight:600, color:"var(--primary)", display:"flex", gap:5, alignItems:"center" }}><Icon name="eye" size={13} />{revealed ? "Hide" : "Reveal"}</button>
              </div>
              <div className="mono" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 12px", background:"var(--code-bg)", border:"1px solid var(--border)", borderRadius:"var(--r-sm)", fontSize:12.5, color:"var(--code-text)" }}>
                <span>{revealed ? fullSecret : secret}</span>
                <Icon name="lock" size={14} style={{ color:"var(--text-3)" }} />
              </div>
            </div>
            <CredRow label="Project / Application Key" value={`prj_${app.code.replace(/-/g, "_")}_${app.env.toLowerCase()}`} />
            <div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text-2)", marginBottom:6 }}>Scopes</div>
              <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                {["agents:invoke", "agents:list", "tools:register", "tools:report", "runs:read"].map(s => <Badge key={s} tone="purple" soft>{s}</Badge>)}
              </div>
            </div>
          </div>
          <div style={{ display:"flex", gap:9, marginTop:18, paddingTop:16, borderTop:"1px solid var(--border)" }}>
            <Btn variant="default" icon="refresh">Regenerate Secret</Btn>
            <Btn variant="soft" icon="copy">Copy config</Btn>
            <div style={{ flex:1 }} />
            <Btn variant="danger" icon="power">Revoke access</Btn>
          </div>
        </Card>
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <Card pad={false}>
          <div style={{ padding:"12px 14px", borderBottom:"1px solid var(--border)", display:"flex", alignItems:"center", gap:8 }}><Icon name="doc" size={15} style={{ color:"var(--primary)" }} /><span style={{ fontSize:12.5, fontWeight:700 }}>.env configuration</span></div>
          <CodeBlock code={envBlock} style={{ border:"none", borderRadius:0 }} copyable />
        </Card>
        <div style={{ display:"flex", gap:10, padding:"12px 14px", background:"var(--amber-100)", borderRadius:"var(--r-md)", border:"1px solid var(--amber-500)" }}>
          <Icon name="shield-alert" size={18} style={{ color:"var(--amber-500)", flexShrink:0 }} />
          <div style={{ fontSize:12, color:"var(--text-2)", lineHeight:1.5 }}>Store the Client Secret in a secrets manager. MAAC never stores application database credentials — client-side tools run inside this application's own boundary.</div>
        </div>
      </div>
    </div>
  );
}
function CredRow({ label, value }) {
  const [copied, setCopied] = useState(false);
  return (
    <div>
      <div style={{ fontSize:12, fontWeight:600, color:"var(--text-2)", marginBottom:6 }}>{label}</div>
      <div className="mono" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 12px", background:"var(--code-bg)", border:"1px solid var(--border)", borderRadius:"var(--r-sm)", fontSize:12.5, color:"var(--code-text)" }}>
        <span>{value}</span>
        <button onClick={() => { navigator.clipboard?.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1200); }} className="maac-link" style={{ border:"none", background:"none", cursor:"pointer", color:copied ? "var(--teal-600)" : "var(--text-3)", display:"flex" }}><Icon name={copied ? "check" : "copy"} size={14} /></button>
      </div>
    </div>
  );
}

function AppHistory({ app, go }) {
  const appRuns = MAAC.runs.filter(r => r.appId === app.id);
  return (
    <Table columns={[{ label:"Run ID" }, { label:"Agent" }, { label:"Caller" }, { label:"Status" }, { label:"Tokens", align:"right" }, { label:"Latency", align:"right" }, { label:"Started", align:"right" }]}>
      {appRuns.map(r => (
        <Tr key={r.id} onClick={() => go("run", { id:r.id })}>
          <Td mono strong>{r.id}</Td>
          <Td>{MAAC.agentById(r.agentId)?.name.replace(" Agent", "")}</Td>
          <Td mono>{r.caller}</Td>
          <Td><RunBadge status={r.status} dot /></Td>
          <Td align="right" mono>{(r.tokensIn + r.tokensOut).toLocaleString()}</Td>
          <Td align="right" mono>{r.latency}</Td>
          <Td align="right" style={{ color:"var(--text-3)" }}>{r.started}</Td>
        </Tr>
      ))}
    </Table>
  );
}

function AppSDK({ app }) {
  const install = `# Install the MAAC SDK
npm install @milaha/maac-sdk`;
  const init = `import { MAACClient } from "@milaha/maac-sdk";

const maac = new MAACClient({
  projectId:     process.env.MAAC_PROJECT_ID,
  clientId:      process.env.MAAC_CLIENT_ID,
  clientSecret:  process.env.MAAC_CLIENT_SECRET,
  environment:   "${app.env.toLowerCase()}",
});

// Discover agents available to this application
const agents = await maac.listAgents();`;
  const handler = `// Register a local handler for a client-side tool.
// MAAC defines the contract; this app owns the execution.
maac.registerTool("getOperationalRecords", async (args, ctx) => {
  if (!ctx.user.hasPermission("ops:read")) {
    return { status: "rejected", reason: "Not permitted" };
  }
  const data = await db.operations.query({
    from: args.from_date, to: args.to_date, vessel: args.vessel_id,
  });
  return { summary: data.summary, records: data.records };
});`;
  const invoke = `// Invoke an agent — pause/resume is handled automatically
const res = await maac.runAgent("operations-summary", {
  input: "Summarize today's operations and flag delays.",
  context: { userId: currentUser.id, department: currentUser.dept },
});
console.log(res.output);`;
  const steps = [
    { n:1, title:"Install the SDK", desc:"Add the MAAC SDK to your application dependencies.", code:install, lang:"bash" },
    { n:2, title:"Initialize the client", desc:"Configure with the credentials from the Credentials tab.", code:init, lang:"typescript" },
    { n:3, title:"Register client-side tool handlers", desc:"Implement each required tool against your own data & permissions.", code:handler, lang:"typescript" },
    { n:4, title:"Invoke agents", desc:"MAAC pauses for client tools and resumes after your handler responds.", code:invoke, lang:"typescript" },
  ];
  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:14 }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        {steps.map(s => (
          <Card key={s.n}>
            <div style={{ display:"flex", gap:12, marginBottom:12 }}>
              <span style={{ width:26, height:26, borderRadius:8, background:"var(--primary)", color:"var(--primary-contrast)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:700, flexShrink:0 }}>{s.n}</span>
              <div><div style={{ fontSize:14, fontWeight:700 }}>{s.title}</div><div style={{ fontSize:12.5, color:"var(--text-3)", marginTop:1 }}>{s.desc}</div></div>
            </div>
            <CodeBlock code={s.code} lang={s.lang} />
          </Card>
        ))}
      </div>
      <div>
        <Card style={{ position:"sticky", top:0 }}>
          <SectionHeader title="Setup status" icon="check2" />
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            <SetupCheck label="SDK installed" done />
            <SetupCheck label="Client initialized" done />
            <SetupCheck label={`Tool handlers (${app.toolsImplemented}/${app.toolsRequired})`} done={app.toolsImplemented === app.toolsRequired} />
            <SetupCheck label="First agent invoked" done={app.status === "Active"} />
          </div>
          <Btn variant="soft" size="sm" full style={{ marginTop:14 }} icon="book">Full SDK documentation</Btn>
        </Card>
      </div>
    </div>
  );
}
function SetupCheck({ label, done }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:10, fontSize:12.5 }}>
      <span style={{ width:20, height:20, borderRadius:999, display:"flex", alignItems:"center", justifyContent:"center", background:done ? "var(--teal-500)" : "var(--surface-3)", color:done ? "#fff" : "var(--text-3)", border:done ? "none" : "1px solid var(--border-2)", flexShrink:0 }}>{done ? <Icon name="check" size={12} strokeWidth={3} /> : <span style={{ width:6, height:6, borderRadius:6, background:"var(--text-3)" }} />}</span>
      <span style={{ fontWeight:500, color:done ? "var(--text)" : "var(--text-2)" }}>{label}</span>
    </div>
  );
}

Object.assign(window, { Applications, ApplicationDetail, AppMark });
